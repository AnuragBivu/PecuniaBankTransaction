package com.capgemini.pecunia.repository;

import java.util.ArrayList;

import com.capgemini.pecunia.controller.Transaction;

public class TransactionRepository {


	
}

