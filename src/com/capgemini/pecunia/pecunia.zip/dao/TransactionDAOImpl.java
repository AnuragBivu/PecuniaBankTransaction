package com.capgemini.pecunia.dao;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.pecunia.controller.Account;
import com.capgemini.pecunia.controller.Transaction;

@SuppressWarnings("unused")
public class TransactionDAOImpl implements TransactionDAO{
	
	Transaction transaction = new Transaction();
	//Account account = new Account();
	
	public double balance;
	
	public TransactionDAOImpl() {
		//TODO
	}
	
	public double getBalance(Account A)
	{
		balance = A.getBalance();
		return balance;
	}
	
	public boolean updateBalance(Account A, double amount)
	{
		double balance = getBalance(A);
		A.setBalance(balance + amount);
		return true;
	}
	
//	public int generateChequeId(Cheque C)
//	{
//		
//	}
	
//	public int generateTransactionId(Transaction T)
//	{
//		
//	}
	
//	public Account getAccountById(String AccountID)
//	{
//		
//	}
	
//	public void addSomeAccountDetails() {
//		Transaction ta1=new Transaction("Kavya","123456789012",2000,
//				Arrays.asList(new Transaction("1000000001L",LocalDate.now())));
//		Transaction ta2=new Transaction("Madhuri","987654321012",3000,
//				Arrays.asList(new Transaction("1000000002L",LocalDate.now())));
//		transaction.put(ta1.getAccountNumber(), ta1);
//		transaction.put(ta2.getAccountNumber(), ta2);
//	}
//
//	public boolean addAcountDetails(Transaction accountDetails) {
//		if(transaction.containsKey(accountDetails)) {
//			return false;
//		}
//		transaction.put(accountDetails.getAccountNumber(), accountDetails);
//		return true;
//	}
//   
//	public boolean creditUsingSlip(String userName, String accountNumber,double amount) {
//	
//	try {
//			if(amount<=100||amount>=100000) {
//				throw new Exception("Insufficient");
//			}
//		else if((accountNumber).length()!=12){
//			throw new Exception("Invalid account number");
//		}
//	
//			addAmount( accountNumber, amount) ;
//	System.out.println("Deposited"+amount+".rs Successfully total amount"+getBalanceById( accountNumber));
//	}
//	catch(Exception e) {
//		System.out.println(e.getMessage());
//	}
//	return false;
//	}
//
//	public boolean debitUsingSlip(String userName, String accountNumber,double amount) {
//	
//		try {
//			if(amount<=100||amount>=100000) {
//				throw new Exception("Insufficient");
//			}
//		else if((accountNumber).length()!=12){
//			throw new Exception("Invalid account number");
//		}
//	
//			deductAmount(accountNumber, amount);
//	System.out.println("withdrawn"+amount+".rs Successfully total amount"+  getBalanceById( accountNumber));
//	}
//	catch(Exception e) {
//		System.out.println(e.getMessage());
//	}
//	return false;
//	}
//
//	public int getBalanceById(String accountNumber) {
//		if(!transaction.containsKey(accountNumber)) {
//			System.out.println("No Account Found");
//			return 0;
//		}
//		Transaction b=transaction.get(accountNumber);
//		return (int) b.getBalance();
//	}
//
//	public boolean updateAccountBalance(Transaction accountDetails, double amount) {
//		if(!transaction.containsKey(accountDetails.getAccountNumber())) {
//		return false;
//	}
//		
//		return true;
//	}
//	
//public boolean deductAmount(String accountNumber,double amount) {
//		if(!transaction.containsKey(accountNumber)) {
//			return false;
//		}
//		Transaction acc=transaction.get(accountNumber);
//		acc.setBalance(acc.getBalance()-amount);
//		return true;
//	}
//
//public boolean addAmount(String accountNumber,double amount) {
//	if(!transaction.containsKey(accountNumber)) {
//		return false;
//	}
//	Transaction acc=transaction.get(accountNumber);
//	acc.setBalance(acc.getBalance()+amount);
//	return true;
//}
}
