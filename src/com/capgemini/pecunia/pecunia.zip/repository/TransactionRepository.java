package com.capgemini.pecunia.repository;

import java.util.ArrayList;

import com.capgemini.pecunia.controller.Transaction;

public class TransactionRepository {
	static ArrayList <Transaction> transcationData=new ArrayList <Transaction>();

	public static ArrayList<Transaction> getSlipdata() {
		return transcationData;
	}

	public TransactionRepository(Transaction transcation) {
		transcationData.add(transcation);
	}

	
}

